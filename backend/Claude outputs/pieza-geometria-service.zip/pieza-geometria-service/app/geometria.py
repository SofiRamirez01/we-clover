"""
Logica de geometria reusada del repo original (RomaHerot/OptimizacionCorteTextil),
sacando las partes de consola (input()/print() interactivos) y de graficado
(matplotlib), que no tienen sentido dentro de un servicio HTTP.

Equivalencia con el repo original:
- crear_poligono()   -> reemplaza la construccion manual de Polygon que hacia
                        polymaker.prompt_polygon_from_user() a partir de los
                        vertices ingresados por consola.
- calcular_medidas() -> no existia como funcion propia en el repo original; Shapely
                        ya expone .area y .bounds gratis sobre cualquier Polygon,
                        ahora simplemente se empaquetan en un dict para la respuesta
                        HTTP.
- aplicar_margen()   -> es la misma logica de polyorder.create_margin_polygons(),
                        adaptada para una sola pieza en vez de una lista.
"""

from shapely.geometry import MultiPolygon, Polygon


class PoligonoInvalidoError(Exception):
    """Se lanza cuando las coordenadas recibidas no arman un poligono valido."""


def crear_poligono(coordenadas: list[tuple[float, float]]) -> Polygon:
    if len(coordenadas) < 3:
        raise PoligonoInvalidoError(
            "Un poligono necesita al menos 3 vertices (se recibieron "
            f"{len(coordenadas)})."
        )

    poligono = Polygon(coordenadas)

    if not poligono.is_valid:
        raise PoligonoInvalidoError(
            "Las coordenadas no forman un poligono valido (revisar que los "
            "segmentos no se crucen entre si)."
        )

    return poligono


def calcular_medidas(poligono: Polygon) -> dict:
    minx, miny, maxx, maxy = poligono.bounds
    return {
        "areaCm2": poligono.area,
        "anchoCm": maxx - minx,
        "largoCm": maxy - miny,
        "perimetroCm": poligono.length,
    }


def aplicar_margen(poligono: Polygon, margen_costura_cm: float) -> Polygon:
    """Misma logica que polyorder.create_margin_polygons(), para una sola pieza."""
    margen = poligono.buffer(margen_costura_cm, join_style=2)

    # Igual que en el repo original: un buffer puede devolver un MultiPolygon en
    # geometrias raras (ej. formas muy concavas); nos quedamos con la parte mas
    # grande, tal cual hacia polyorder.create_margin_polygons().
    if isinstance(margen, MultiPolygon):
        margen = max(margen.geoms, key=lambda p: p.area)

    return margen


def poligono_a_coordenadas(poligono: Polygon) -> list[list[float]]:
    return [[float(x), float(y)] for x, y in poligono.exterior.coords]
