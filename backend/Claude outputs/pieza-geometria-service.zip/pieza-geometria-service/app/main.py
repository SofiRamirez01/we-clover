"""
Servicio HTTP de calculo geometrico para el modulo de Piezas (requisito 4.1 del
S.G.O.T.). Reemplaza el flujo de consola de polymaker.py/polyorder.py del repo
RomaHerot/OptimizacionCorteTextil por un unico endpoint que el backend Java llama
por HTTP.

No persiste nada (es stateless): la persistencia de Pieza/PiezaTalle vive en el
backend Java, en la misma base de datos que el resto del sistema.

Correr en desarrollo:
    uvicorn app.main:app --reload --port 8000

Ejemplo de request:
    POST http://localhost:8000/piezas/calcular
    {
      "coordenadas": [[0, 0], [70, 10], [80, 100], [30, 110]],
      "margenCosturaCm": 5
    }
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from app.geometria import (
    PoligonoInvalidoError,
    aplicar_margen,
    calcular_medidas,
    crear_poligono,
    poligono_a_coordenadas,
)

app = FastAPI(
    title="Servicio de Geometria de Piezas",
    description="Calculo de medidas y margen de costura para el modulo de Piezas de moldería.",
    version="1.0.0",
)


class CalcularPiezaRequest(BaseModel):
    coordenadas: list[tuple[float, float]] = Field(
        ..., min_length=3, description="Vertices del contorno de la pieza, en cm."
    )
    margenCosturaCm: float = Field(..., gt=0, description="Offset de margen de costura, en cm.")


class CalcularPiezaResponse(BaseModel):
    areaCm2: float
    anchoCm: float
    largoCm: float
    perimetroCm: float
    coordenadasMargen: list[list[float]]


@app.post("/piezas/calcular", response_model=CalcularPiezaResponse)
def calcular_pieza(request: CalcularPiezaRequest) -> CalcularPiezaResponse:
    try:
        poligono_base = crear_poligono(request.coordenadas)
    except PoligonoInvalidoError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error

    medidas = calcular_medidas(poligono_base)
    poligono_margen = aplicar_margen(poligono_base, request.margenCosturaCm)

    return CalcularPiezaResponse(
        areaCm2=medidas["areaCm2"],
        anchoCm=medidas["anchoCm"],
        largoCm=medidas["largoCm"],
        perimetroCm=medidas["perimetroCm"],
        coordenadasMargen=poligono_a_coordenadas(poligono_margen),
    )


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}
