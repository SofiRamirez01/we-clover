# Servicio de Geometria de Piezas

Microservicio Python para el requisito 4.1 (Piezas de moldería) del S.G.O.T.
Reemplaza el flujo de consola de `polymaker.py` / `polyorder.py` del repo
[RomaHerot/OptimizacionCorteTextil](https://github.com/RomaHerot/OptimizacionCorteTextil)
por un endpoint HTTP que el backend Java (Spring) consume.

Este servicio es stateless: no guarda `polygons.json` ni `patrones.json` como hacia
el repo original. La persistencia (`Pieza`, `PiezaTalle`) vive en el backend Java, en
la misma base de datos que el resto del sistema.

## Como correrlo

```bash
python -m venv .venv
source .venv/bin/activate   # en Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Documentacion interactiva (Swagger) una vez levantado: http://localhost:8000/docs

## Endpoint

`POST /piezas/calcular`

Request:
```json
{
  "coordenadas": [[0, 0], [70, 10], [80, 100], [30, 110]],
  "margenCosturaCm": 5
}
```

Response:
```json
{
  "areaCm2": 6350.0,
  "anchoCm": 80.0,
  "largoCm": 110.0,
  "perimetroCm": 297.4,
  "coordenadasMargen": [[-4.4, -3.9], ["..."]]
}
```

El backend Java persiste `coordenadas` (tal cual las ingreso el usuario) y
`coordenadasMargen`/`areaCm2`/`anchoCm`/`largoCm` (lo que devuelve este servicio) en
la tabla `pieza_talles`, junto con a que `Pieza` y a que fila de `TablaTalle`
corresponden.

## Que se dejo afuera a proposito

Del repo original solo se reusa la logica pura de geometria (crear el poligono,
calcular area/bounding box, aplicar el margen de costura via `buffer()`). Se dejo
afuera:

- Todo lo que era `input()`/`print()` de consola (`prompt_polygon_from_user`,
  `prompt_polygon_selection`, etc.) — ya no aplica, las coordenadas llegan por HTTP
  desde la pantalla de carga de Piezas.
- El guardado en `polygons.json`/`patrones.json` — la persistencia ahora es la base
  de datos del backend Java.
- Los archivos sueltos que no eran parte del flujo real: `mainEster.py`,
  `import random.py`, `main.py` (vacio), `setup.py` (empaquetaba un ejecutable de
  escritorio, no aplica a un servicio).

## Algoritmo de optimizacion de corte (fase futura, NO wireado todavia)

`algorpatronsnap.py` (el archivo definitivo del algoritmo genetico de optimizacion
de layout, segun confirmo Sofia) y `polyorder.py` original (del que depende) quedaron
copiados sin modificar en `optimizacion_futura/`, listos para cuando se encare esa
fase — no se tocan ni se exponen por ningun endpoint en esta entrega.
